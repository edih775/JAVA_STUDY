package chat.client;
 
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
 
public class ClientBackground {
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private ClientGUI gui;
    private String msg;
    private String nickName;
 
    public void setGui(ClientGUI gui) {
        this.gui = gui;
    }
    
    public static void main(String[] args) {
        ClientBackground clientBackground = new ClientBackground();
        clientBackground.connect();
    }
    //Ŭ���̾�Ʈ ������ �Ϸ�Ǹ� 
    public void connect(){
        try {
            socket = new Socket("172.16.26.176", 7777);
            System.out.println("������ �����");
            
            out = new DataOutputStream(socket.getOutputStream());
            in = new DataInputStream(socket.getInputStream());
            
            //�������ڸ��� �г��� �����ϸ�, ������ �г������� �ν� 
            out.writeUTF(nickName);
            System.out.println("Ŭ���̾�Ʈ : �г��� ���ۿϷ� ");
            
            while(in!=null){
                msg = in.readUTF();
                gui.appendMsg(msg);
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendMessage(String msg){
        try {
            out.writeUTF(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void setNickname(String nickName){
        this.nickName = nickName;
    }
    
}
